// Importar paquete de mongoose
const mongoose = require("mongoose");
// Importar el modelo de documentos de posteos
const BlogPost = require("./models/BlogPost");

// Arreglo de objetos que simulen una tabla de posteos
const blogPosts = [
  {
    title: "Wikipedia",
    content:
      "Wikipedia es una enciclopedia libre,[nota 2]​ políglota y editada de manera colaborativa. Es administrada por la Fundación Wikimedia, una organización sin ánimo de lucro cuya financiación está basada en donaciones. Sus más de 63 millones de artículos en 334 idiomas han sido redactados en conjunto por voluntarios de todo el mundo,[5]​ lo que suma más de 3500 millones de ediciones, y permite que cualquier persona pueda sumarse al proyecto[6]​ para editarlos, a menos que la página se encuentre protegida contra vandalismos para evitar problemas o disputas.",
    author: "Juan Perez",
  },
  {
    title: "Node.js",
    content:
      "Node.js es un entorno en tiempo de ejecución multiplataforma, de código abierto, para la capa del servidor (pero no limitándose a ello) basado en el lenguaje de programación JavaScript, asíncrono, con E/S de datos en una arquitectura orientada a eventos y basado en el motor V8 de Google. Fue creado con el enfoque de ser útil en la creación de programas de red altamente escalables, como por ejemplo, servidores web.[4]​ Fue creado por Ryan Dahl en 2009 y su evolución está apadrinada por la empresa Joyent, que además tiene contratado a Dahl en plantilla.[5]​[6]",
    author: "María Islas",
  },
  {
    title: "Express.js",
    content:
      "Express.js o simplemente Express es un entorno de trabajo para aplicaciones web en Node.js, de código abierto y con licencia MIT. Se utiliza para desarrollar aplicaciones web y APIs. El autor original es TJ Holowaychuk y la primera versión se lanzó el 2010. Express.js forma parte del programario MEAN, juntamente con MongoDB, Angular.js y Node.js.",
    author: "Christian Ruiz",
  },
];

// Conectarse a la base de datos de posteos de blog en MongoDB
// (si no existe la base de datos, se crea y se conecta en ella)

mongoose
  .connect("mongodb://127.0.0.1:27017/blogpostsdb")
  .then(() => {
    console.log("Conectanddo al servidor de MongoDB...");
  })
  .catch((err) => {
    console.log(`Error de MongoDD: ${err}`);
  });

/**
 * Función para crear un documento de un posteo. La infromacion del documento
 * se recibe como un objeto de JavaSript
 */
async function crearDocumento(blogPost) {
  try {
    // Crear un documento en la base de datos a partir del parametro
    const newBlogPost = await BlogPost.create(blogPost);
    // Verificar si no se creo el documento
    if (!newBlogPost) {
      console.log("No fue posible crear el documento");
      process.exit(1);
    }
    //Desplegar el nuevo documento
    console.log(newBlogPost);
  } catch (err) {
    console.log(err);
    process.exit(1); // Salir de la aplicación con codigo de error
  }
}

/**
 * Función para crear varios documentos a partir
 * del arreglo de objetos de posteos
 */
async function crearDocumentos() {
  try {
    // Recorrer el arreglo para crear los documentos
    for (let b of blogPosts) {
      await crearDocumento(b);
    }
    console.log("Documentos creados exitosamente");
    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

/**
 * Fumción para recuperar todos los documentos de la colección
 */
async function leerDocumentos() {
  try {
    // Leer toos los documentos
    const posts = await BlogPost.find({}, { __v: 0 });
    // Desplegar en pantalla
    console.log(posts);
    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

/**
 * Función para recuperar un documento específico a partir de su ID
 */

async function leerDocumento(id) {
  try {
    // Leer documento
    const post = await BlogPost.findById(id, { __v: 0 });
    // Verificar si no se encontro el documento
    if (!post) {
      console.log("Documento no encontrado");
      process.exit(1);
    }
    // desplegar el documento
    console.log(post);
    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

/**
 * Función para eliminar un documento en particular dado su id.
 */
async function eliminarDocumento(id) {
  try {
    // Eliminar el documento
    const deletedPost = await BlogPost.findByIdAndDelete(id);
    // Verificar si no se encontró el documento por eliminar
    if (!deletedPost) {
      console.log("Documento no encontrado");
      process.exit(1);
    }
    // Mostrar el documento eliminado
    console.log(deletedPost);
    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

/**
 * Funcion par actualizar uno o mas propiedades del documento
 * especificado. Los parametro correspondientes  las propiedades
 * por actualizar se pasan dentro de un objeto y se leerán por
 * "Desestructuración"
 */
async function actualizarDocumento(id, { title, content, author }) {
  try {
    // Actualizar el documento
    const updatePost = await BlogPost.findByIdAndUpdate(id, {
      title,
      content,
      author,
    });
    // Verificar si no se encontro el documento
    if (!updatePost) {
      console.log("Documento no encontrado");
      process.exit(1);
    }
    // Mostrar documento actualizado
    //console.log(updatePost);
    console.log("Documento actualizado exitosamente!");
    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

/**
 * Llamadas a las funciones de crud
 */
//crearDocumentos();
//leerDocumentos();
//leerDocumento("68e00b7055d1484db835c660");
//eliminarDocumento("68d6ee0cc4c2a7b4325885b6");
actualizarDocumento("68d6ee0cc4c2a7b4325885b8", { title: "Nuevo titulo" });
