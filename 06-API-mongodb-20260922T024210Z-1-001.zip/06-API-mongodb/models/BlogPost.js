const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Definir el esquema para los documentos de los posteos de blog
const blogPostSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  content: {
    type: String,
    required: true,
  },
  author: {
    type: String,
    required: true,
  },
  postDate: {
    type: Date,
    default: Date.now, // Fechs y Hora actuales
  },
  views: {
    type: Number,
    default: 0,
  },
});

// Crear el modelo de los posteos a partir del esquema
const BlogPost = mongoose.model('BlogPost', blogPostSchema);

// Exportar el modelo
module.exports = BlogPost;
