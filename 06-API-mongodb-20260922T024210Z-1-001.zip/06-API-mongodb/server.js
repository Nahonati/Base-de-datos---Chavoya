const express = require('express');
const mongoose = require('mongoose');
const BlogPost = require('./models/BlogPost');

const port = 4000;

// Conectar al servidor de mongoDb
mongoose
  .connect('mongodb://127.0.0.1:27017/blogpostsdb')
  .then(() => {
    console.log('Connected to MongoDB server...');
  })
  .catch((err) => {
    console.log(`MongoDD server errror!: ${err}`);
  });

// Crear aplicación express
const app = express();

// Especificar que se puede recibir datos en formato Json
// o urlencoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Get de ruta '/'
app.get('/', (req, res) => {
  res.json({ status: 'succes', message: 'BlogPosts API' });
});

//Get de '/blogposts' para regresar todos los posteos
app.get('/blogposts', async (req, res) => {
  try {
    //Leer todos los posteos
    const posts = await BlogPost.find({}, { __v: 0 });
    // Regresar respuesta
    res.json({
      status: 'success',
      data: {
        blogpost: posts,
      },
    });
  } catch (err) {
    console.log(err);
  }
});

// Get ruta '/blogposts:id' para regresar un posteo particular
app.get('/blogposts/:id', async (req, res) => {
  try {
    // leer id del URL
    const postID = req.params.id;
    // leer posteo particular
    const post = await BlogPost.findById(postID, { __v: 0 });
    // Verifivar si no se encontro e posteo
    if (!post) {
      return res.status(404).json({
        status: 'fail',
        message: 'Post not found',
      });
    }

    // Todo actualiza el numero de vistas
    post.views++;

    // Actualizar el numero de vistas en la base de datos
    await BlogPost.findByIdAndUpdate(postID, { $inc: { views: 1 } });
    //Regresar el posteo encontrado
    res.json({
      status: 'sucess',
      data: {
        blogpost: post,
      },
    });
  } catch (err) {
    console.log(err);
  }
});

// Post tuta '/blogpost' para subir un nuevo posteo
app.post('/blogposts', async (req, res) => {
  try {
    // Verificar si no se tiene nada de información (title, content, author)
    if (!req.body) {
      return res.status(400).json({ status: 'fail', message: 'Missing Data' });
    }
    let { title, content, author } = req.body;

    // Eliminat posibles espacios en blanco antes y después del dato
    if (title) title = title.trim();
    if (content) content = content.trim();
    if (author) author = author.trim();

    // Verificar si no se tiene toda la información (title, content, author)
    if (!title || !content || !author) {
      return res.status(400).json({ status: 'fail', message: 'Missing Data' });
    }

    // Subir un nuevo documento a partir de un objeto
    const newPost = await BlogPost.create({
      title,
      content,
      author,
    });

    //Verificar si no se creo el posteo
    if (!newPost) {
      return res.status(400).json({
        status: 'fail',
        message: 'Invalid data',
      });
    }

    // Regresar informacion del nuevo posteo
    res.status(201).json({
      status: 'success',
      data: {
        newblogposts: newPost,
      },
    });
  } catch (err) {
    console.log(err);
  }
});

// PATCH ruta /'blogposts/:id'
app.patch('/blogposts/:id', async (req, res) => {
  try {
    const postID = req.params.id;

    // Verificar si no existe el objeto req.body
    if (!req.body) {
      return res.status(404).json({ status: 'fail', message: 'Missing Data' });
    }
    console.log(req.body);

    // Recuperar la información modificar del cuerpo de la petición
    let { title, content, author } = req.body;

    // Eliminar espacios en blanco antes y después del dato
    if (title) title = title.trim();
    if (content) content = content.trim();
    if (author) author = author.trim();

    //console.log({ title, content, author });

    // Verificar si no se envió por lo menos uno de los tres campos
    if (!(title || content || author)) {
      return res.status(404).json({ status: 'fail', message: 'issing data' });
    }

    // Actualizar documento en la base de datos
    const updatedPost = await BlogPost.findByIdAndUpdate(postID, {
      title,
      content,
      author,
    });

    // Verificar si no se encontro el documento
    if (!updatedPost) {
      return res
        .status(404)
        .json({ status: 'fail', message: 'Post not found' });
    }

    // Regresar mensaje de exito
    res.json({
      status: 'success',
      data: null,
    });
  } catch (err) {
    console.log(err);
  }
});

// DELETE ruta '/blogposts/:id' para eliminar un posteo
app.delete('/blogposts/:id', async (req, res) => {
  try {
    // Obtener el id del posteo a eliminar
    const postID = req.params.id;

    // Eliminar el doc de la base de datos
    const deletedPost = await BlogPost.findByIdAndDelete(postID);

    //Verificar si no se encontro el doc
    if (!deletedPost) {
      return res.status(404).json({
        status: 'fail',
        message: 'Post not found',
      });
    }

    // Regresar mensaje e exito
    res.json({
      status: 'success',
      data: null,
    });
  } catch (err) {
    console.log(err);
  }
});

// Recurso no encontrado
app.use((req, res) => {
  res.status(404).json({ status: 'fail', message: 'Not found' });
});

// Error del servidor
app.use((err, req, res) => {
  res.status(500).json({ status: 'error', message: 'Server error' });
});

// iniciar el servidor para escuchar peticiones
app.listen(port, () => {
  console.log(`Server listening on port ${port}...`);
});
