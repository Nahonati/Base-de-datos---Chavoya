// Importar paquete Express para crear servidor web
const express = require("express");
// Importar paquete "path" de (Node) para manejo de rutas
// de archivo
const path = require("path");
// Número de puerto para escuchar peticiones
const puerto = 3000;

// Crear aplicación del servidor web de Express
const app = express();

// Especificar la ruta para la carpeta 'public' con archivos estaticos
app.use(express.static(path.resolve(__dirname, "public")));

// Escuchar peticiones para cada ruta
app.get("/", (req, res) => {
  // Regresar respuesta en formato JSON para probar funcionalidad
  //   res.json({ name: "Página principal" });
  console.log(__dirname);
  // Regresar el archivo html correspondiente a la pagina principal (index.html)
  res.sendFile(path.resolve(__dirname, "public/index.html"));
});

// Escuchar peticiones de las otras rutas
app.get("/about", (req, res) => {
  res.sendFile(path.resolve(__dirname, "public/about.html"));
});

app.get("/contac", (req, res) => {
  res.sendFile(path.resolve(__dirname, "public/contac.html"));
});

// Rutas que no coinciden con ninguna de las rutas anteriores
//(este codigo debe colocarse después de las rutas conocidas)
app.use((req, res) => {
  // Establecer codigo de recurso no encontrado
  res.status(404);
  res.sendFile(path.resolve(__dirname, "public/notfound.html"));
});

// Manejador de errores del servidor, donde el primer argumento de
// la "callback function" debe ser un objeto de tipo error
app.use((err, req, res) => {
  // Establecer codigo de recurso no encontrado
  res.status(500);
  res.sendFile(path.resolve(__dirname, "public/error.html"));
});

// TODO Escuchar peticiones de las otras rutas

// Ejecutar servidor para escuchar peticiones
app.listen(puerto, () => {
  console.log(`Servidor escuchando peticiones en el puerto ${puerto}...`);
});
