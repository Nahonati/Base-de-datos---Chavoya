// exports.getUsers = (req, res, next) => {
//   res.send("respond with a resource");
// };

exports.getLogInUser = (req, res, next) => {
  let email;

  // Recuperar información de la memoria flash (sin considerar la contraseña)
  const data = req.flash("data")[0];

  // verificar si hay información
  if (data) {
    email = data.email;
  }

  // Obtener la lista de mensajes de error
  const validationErrors = req.flash("validationErrors");

  res.render("login", {
    email,
    validationErrors,
  });
};

// Ruta: /users/new para registrar a un nuevo usuario
exports.getNewUser = (req, res, next) => {
  let name;
  let email;

  // Recuperar información de la memoria flash (sin considerar la contraseña)
  const data = req.flash("data")[0];

  // verificar si hay información
  if (data) {
    name = data.name;
    email = data.email;
  }

  // Obtener la lista de mensajes de error
  const validationErrors = req.flash("validationErrors");

  res.render("register", {
    name,
    email,
    validationErrors,
  });
};
