// Importar el modelo
const BlogPost = require("../models/BlogPost");

exports.getRoot = async (req, res, next) => {
  try {
    //Leer todos los posteos
    const posts = await BlogPost.find({}, { __v: 0 }).populate({
      path: "userId",
    });
    //console.log(posts);

    res.render("index", { posts });
  } catch (err) {
    next(err);
  }
};
// exports.getRoot = (req, res, next) => {
//   res.render("index", { title: "Express" });
// };

exports.getAbout = (req, res, next) => {
  res.render("about");
};

exports.getContac = (req, res, next) => {
  res.render("contact");
};
