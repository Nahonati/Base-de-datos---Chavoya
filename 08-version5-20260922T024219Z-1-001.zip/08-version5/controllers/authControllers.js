// Controladores para autenticación (registro de usuarios) e inición de sesión y
// autorización (controlar acceso a ciertos recursos)

const jwt = require("jsonwebtoken");
const User = require("../models/User");

exports.signin = async (req, res, next) => {
  try {
    // Recuperar la información de inicio de sesion
    const { email, password } = req.body;

    //console.log({ email, password });

    // Autenticar que el usuario sea valido

    // Verificar si no se introdujo email y contraseña
    if (!email || !password) {
      // Crear arreglo con mensaje de error y poner en la memoria flash
      req.flash("validationErrors", ["Please provide email and password"]);

      // Guardar infromación capturada por el usuario en la memoria flash
      req.flash("data", req.body);

      // Redirigir a la página de login
      return res.redirect(303, "/users/login");
    }

    // Recuperar usuario con el email, incluyendo la contraseña
    const user = await User.findOne({ email }).select("+password");
    console.log(user);
    // Verificar si no existe el usuario o si la contraseña no es correcta
    if (!user || !(await user.correctPassword(password))) {
      // Crear arreglo con mensaje de error y poner en la memoria flash
      req.flash("validationErrors", ["Incorrect email or password"]);

      // Guardar infromación capturada por el usuario en la memoria flash
      req.flash("data", req.body);

      // Redirigir a la página de login
      return res.redirect(303, "/users/login");
    }

    // Autorización usando json web token

    // Crear el token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });

    //console.log(token);

    //Opciones de la cookie con el token que se guardará en el navegador del cliente
    // cada vez que el cliente (navegador) haga una petición al servidor, el objeto
    // de la petición (request) contendrá la cookie con el token
    const cookieOptions = {
      //Expira en 90 días (el mismo tiempo que el JWT)
      expires: new Date(
        Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 1000 * 60 * 60 * 25
      ),
      // Para que no pueda ser leída por las personas, sino que solo sea enviada
      // y recibida por el navegador
      httpOnly: true,
    };

    // Enviar la cookie con el token al cliente (navegador) en el objeto de la respuesta
    res.cookie("jwt", token, cookieOptions);

    // FIN DE LA SECCIÓN DE AUTORIZACIÓN

    res.redirect(303, "/");
  } catch (err) {
    // Tomar del objeto err los mensajes de error generados y gurdarlos en un arreglo
    const validationErrors = Object.values(err.errors).map(
      (error) => error.message
    );
    // console.log(validationErrors);
    // return next(err);

    // Guardar en a memoria flash la información capturada previamente por el usuario
    req.flash("data", req.body);

    // Guardar el arreglo con los mensajes de error en la memoria flash
    req.flash("validationErrors", validationErrors);

    // Redirigir a la pagina de "New Post"
    res.redirect(303, "/users/login");
  }
};

exports.signout = (req, res, next) => {
  //Opciones para la cookie con el token
  const cookieOptions = {
    // Forzar a que la cookie expire dentro de 10 segundos
    expires: new Date(Date.now() + 10 * 1000),
    httpOnly: true,
  };

  //Sobreescribir el token en la cookie
  res.cookie("jwt", "loggedout", cookieOptions);

  // Redirigir a la página de inicio de sesión
  return res.redirect(303, "/users/login");
};

// Ruta: /users/signup para dar de alta a un nuevo usuario
exports.signup = async (req, res, next) => {
  try {
    //Obtener la información del formulario de Register
    const { name, email, password, passwordConfirm } = req.body;

    //console.log({ name, email, password, passwordConfirm });

    // Crear objeto del usuario y guardar el documento en la base de datos
    const newUser = await User.create({
      name,
      email,
      password,
      passwordConfirm,
    });

    // Autorización usando json web token

    // Crear el token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });

    //console.log(token);

    //Opciones de la cookie con el token que se guardará en el navegador del cliente
    // cada vez que el cliente (navegador) haga una petición al servidor, el objeto
    // de la petición (request) contendrá la cookie con el token
    const cookieOptions = {
      //Expira en 90 días (el mismo tiempo que el JWT)
      expires: new Date(
        Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 1000 * 60 * 60 * 25
      ),
      // Para que no pueda ser leída por las personas, sino que solo sea enviada
      // y recibida por el navegador
      httpOnly: true,
    };

    // Enviar la cookie con el token al cliente (navegador) en el objeto de la respuesta
    res.cookie("jwt", token, cookieOptions);

    // FIN DE LA SECCIÓN DE AUTORIZACIÓN

    // Redirigir a la página principal
    res.redirect(303, "/");
  } catch (err) {
    //console.log(err);
    // Tomar del objeto err los mensajes de error generados y gurdarlos en un arreglo
    const validationErrors = Object.values(err.errors).map(
      (error) => error.message
    );
    // console.log(validationErrors);
    // return next(err);

    // Guardar en a memoria flash la información capturada previamente por el usuario
    // en los campos "title" y "content"
    req.flash("data", req.body);

    // Guardar el arreglo con los mensajes de error en la memoria flash
    req.flash("validationErrors", validationErrors);

    // Redirigir a la pagina de "New Post"
    res.redirect(303, "/users/new");
  }
};

/**
 * Función de middlware para autorizar acceso a ciertos recursos
 */
exports.protect = async (req, res, next) => {
  try {
    // Intentar recuperar el token y verificar si existe
    const token = req.cookie.jwt;

    if (!token) {
      // El usuario no ha iniciado sesión
      //Redirigir a la página de inicio de sesión
      return res.redirect(303, "/users/login");
    }

    // Verificar la validez del token (si no es valido se lanza un error)
    // y obtener la información del usuario (payload) del token
    const decoded = await jwt.verify(token, process.env.JWT_SECRET);

    // Verificar si el usuario existe
    const currentUser = await User.findById(decoded.id);

    if (!currentUser) {
      //Redirigir a la página de inicio de sesión
      return res.redirect(303, "/users/login");
    }

    //Guardar el objeto del usuario en el objeto de ña petición para que opcionalmente
    // pueda ser usado por los siguientes elementos de middleware
    req.user = currentUser;

    // Pasar el control al siguiente elemento del middleware habiendo autorizado
    // el usuario a ciertos recursos
    next();
  } catch (err) {
    //Redirigir a la página de inicio de sesión
    return res.redirect(303, "/users/login");
  }
};

/**
 * Función de middleware para determinar si el usuario ha iniciado o no sesión
 * Si el usuario ha iniciado sesión, guardar el objeto del usuario en el objeto
 * de la petición para poder ser utilizado en los siguientes elementos de middleware
 * Adicionalmente, si el usuario inició sesión, el objeto del usuario se pondra
 * como variable para las páginas EJS (para control de las opciones de la barra de navegación).
 */
exports.isLoggedIn = async (req, res, next) => {
  try {
    // Asumir que el usuario no ha inicado sesión (locals es una propiedad
    // para guardar información que puede utilizar una página EJS)
    res.locals.user = undefined;

    // Intentar recuperar el token y verificar si existe
    const token = req.cookie.jwt;

    if (!token) {
      // El usuario no ha iniciado sesión
      //Pasar al siguiente elemento de middleware
      return next();
    }

    // Verificar la validez del token (si no es valido se lanza un error)
    // y obtener la información del usuario (payload) del token
    const decoded = await jwt.verify(token, process.env.JWT_SECRET);

    // Verificar si el usuario existe
    const currentUser = await User.findById(decoded.id);

    if (!currentUser) {
      //Pasar al siguiente elemento de middleware
      return next();
    }

    // Colocar el objeto del usuario el objeto de la petición para poder
    // ser utilizado por los siguientes elementos de middleware
    req.user = currentUser;

    // Colocar el objeto del usuario en las variables utilizadas por las paginas EJS
    res.locals.user = currentUser;

    // Pasar el control al siguiente elemento de middleware
    next();
  } catch (err) {
    // Pasar el control al siguiente elemento de middleware
    next();
  }
};
