const createError = require("http-errors");
const BlogPost = require("../models/BlogPost");

// COntrolador para mostrar la página de un posteo particular
exports.getPost = async (req, res, next) => {
  try {
    // leer id del URL
    const postID = req.params.id;
    // leer posteo particular
    const post = await BlogPost.findById(postID, { __v: 0 }).populate({
      path: "userId",
    });
    // Verifivar si no se encontro e posteo
    if (!post) {
      next(createError(400));
    }

    // Todo actualiza el numero de vistas
    post.views++;

    // Actualizar el numero de vistas en la base de datos
    await BlogPost.findByIdAndUpdate(postID, { $inc: { views: 1 } });

    //Mostrar la página con el posteo encontrado
    res.render("post", { post });
  } catch (err) {
    console.log(err);
  }
};

// Controlador para mostrar la pagina de creacion de un nuevo posteo
exports.getNewPost = (req, res, next) => {
  let title;
  let content;

  //obtener posible información escrita por el usuario ("title" y/o "content")
  const data = req.flash("data")[0]; // Se guarda en un arreglo
  // console.log(data);

  //Obtener información individual
  if (data) {
    title = data.title;
    content = data.content;
  }

  //Obtener posibles mensajes de error de la memoria flash
  const validationErrors = req.flash("validationErrors");
  console.log(validationErrors);

  res.render("create", { title, content, validationErrors });
};

//Controlador para crear un nuevo posteo en la base de datos
exports.createPost = async (req, res, next) => {
  try {
    // Verificar si no se tiene nada de información (title, content, author)
    // if (!req.body) {
    //   return next(createError(400));
    // }

    let { title, content } = req.body;

    //Temporalmente el usuario será fijo
    // const author = "John Wick";

    //Obtener el ID del usuario del objeto req, puesto por el middleware 'protect'

    // Eliminat posibles espacios en blanco antes y después del dato
    // if (title) title = title.trim();
    // if (content) content = content.trim();

    // // Verificar si no se tiene toda la información (title, content, author)
    // if (!title || !content || !author) {
    //   return res.status(400).json({ status: "fail", message: "Missing Data" });
    // }

    // Subir un nuevo documento a partir de un objeto
    const newPost = await BlogPost.create({
      title,
      content,
      // author,
      userId,
    });

    //Verificar si no se creo el posteo
    if (!newPost) {
      return next(createError(400));
    }

    // Redirigir a la pagina que muestra el posteo recién creado
    res.redirect(303, `/posts/id/${newPost._id}`);
  } catch (err) {
    //console.log(err);
    // Tomar del objeto err los mensajes de error generados y gurdarlos en un arreglo
    const validationErrors = Object.values(err.errors).map(
      (error) => error.message
    );
    // console.log(validationErrors);
    // return next(err);

    // Guardar en a memoria flash la información capturada previamente por el usuario
    // en los campos "title" y "content"
    req.flash("data", req.body);

    // Guardar el arreglo con los mensajes de error en la memoria flash
    req.flash("validationErrors", validationErrors);

    // Redirigir a la pagina de "New Post"
    res.redirect(303, "/posts/new");
  }
};
