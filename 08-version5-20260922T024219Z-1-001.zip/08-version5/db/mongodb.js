const mongoose = require("mongoose");

// Función que conecta con la base datos de los posteos
exports.connectToDB = () => {
  // Obtener la cadena de conexión a la base de datos
  let connSting = process.env.LOCAL_DATABASE;
  // Conectar al servidor de mongoDb
  mongoose
    .connect(connSting)
    .then(() => {
      console.log("Connected to MongoDB server...");
    })
    .catch((err) => {
      console.log(`MongoDD server errror!: ${err}`);
      process.exit(1); // Termina ejecución con codigo de error
    });
};
