const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//const { Schema } = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");

// Crear esquema par documentos de Usuario
const userSchema = new Schema({
  name: {
    type: String,
    required: [true, "Please provide your name"],
    minlength: [2, "Name must have at least 2 characters"],
    maxlength: [100, "Name must be at most 100 characteres long"],
    trim: true,
  },
  email: {
    // Actuará como el identificador del usuario
    type: String,
    required: [true, "Please provide you email"],
    lowercase: true, // Guardarlo todo en minusculas
    unique: true, // No se permite emails repetidos en la coleciión de usuarios
    validate: [validator.isEmail, "Please provide a valid email"],
  },
  password: {
    type: String,
    required: [true, "Pleas provide a password"],
    minlength: [8, "Password must have at least 8 characters"],
    select: false, //No mostrar contraseña al consultar los datos de un usuario con find
  },
  passwordConfirm: {
    type: String,
    required: [true, "Please confirm your password"],
    validate: {
      validator: function (pass) {
        return pass === this.password;
      },
      message: "Passwords are not the same",
    },
  },
});

// Middleware para encriptar automaticamente la contraseña antes de guardar el
// documento en la base de datos en Mongo Db
userSchema.pre("save", async function (next) {
  // Verificar si no se a modifiado la contraseña para no encriptar una contraseña
  // ya encriptada
  if (!this.isModified("password")) {
    // No continuar con la encriptación de la contraseña y pasar el control al siguiente
    // elemento de middleware
    return next();
  }

  // Encriptar la contraseña y reemplazar por la contraseña no encriptada
  this.password = await bcrypt.hash(this.password, 12);

  // No guardar la propiedad de confirmación de la contraseña
  this.passwordConfirm = undefined;

  // Continuar con el siguiente elemento de middleware
  next();
});

/**
 * Metodo de Instncia (del usuario) para comprobar si la contraseña
 * provista (candidata) en l página de Log in, corresponde a la contraseña
 * encryptada en la base de datos.
 */

userSchema.methods.correctPassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Crear modelo a partir del Schema
const User = mongoose.model("User", userSchema);

// Exportar el modelo
module.exports = User;
