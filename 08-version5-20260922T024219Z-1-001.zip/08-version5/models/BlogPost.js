const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Definir el esquema para los documentos de los posteos de blog
const blogPostSchema = new Schema({
  title: {
    type: String,
    required: [true, "Please provide a post title"],
    minlength: [3, "Title must have at least 3 characters"],
    maxlength: [150, "Title must be at most 150 chracters"],
    trim: true, //Quitar posibles espacios en blanco antes y después
  },
  content: {
    type: String,
    required: [true, "Please provide some content"],
    minlength: [10, "Content must have at least 10 characters"],
    maxlength: [200000, "Title must be at most 20,000 chracters"],
    trim: true,
  },
  // author: {
  //   type: String,
  //   required: true,
  // },

  //Identificador del usuario que creó el posteo
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },

  postDate: {
    type: Date,
    default: Date.now, // Fechs y Hora actuales
  },
  views: {
    type: Number,
    default: 0,
  },
});

// Crear el modelo de los posteos a partir del esquema
const BlogPost = mongoose.model("BlogPost", blogPostSchema);

// Exportar el modelo
module.exports = BlogPost;
