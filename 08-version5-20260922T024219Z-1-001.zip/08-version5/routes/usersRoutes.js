const express = require("express");
const router = express.Router();
const usersControllers = require("../controllers/userControllers");
const authControllers = require("../controllers/authControllers");

/* GET users listing. */
// router.get("/", usersControllers.getUsers);

// Ruta para mostrar ventana de inicio de sesión (log in)
router.get("/login", usersControllers.getLogInUser);

// Ruta para dar de alta (registrar) a un nuevo usuario
router.get("/new", usersControllers.getNewUser);

// ***** RUTAS PARA AUTENTICACIÓN Y AUTORIZACIÓN ******

// Ruta para iniciar sesión
router.post("/signin", authControllers.signin);

// Ruta para cerrar sesión (log out)
router.get("/logout", authControllers.protect, authControllers.signup);

// Ruta para crear y guardar en la base de datos el documento del usuario
router.post("/signup", authControllers.signup);

module.exports = router;
