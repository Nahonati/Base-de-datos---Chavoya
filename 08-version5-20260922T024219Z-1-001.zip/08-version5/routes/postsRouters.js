const express = require("express");
const router = express.Router();
const postsControllers = require("../controllers/postsControllers");
const authControllers = require("../controllers/authControllers");

// Ruta para mostrar el ´posteo individual
router.get("/id/:id", postsControllers.getPost);

// Ruta para mostrar la página de un nuevo posteo
router.get("/new", authControllers.protect, postsControllers.getNewPost);

// Ruta para subir un nuevo posteo a la base de datos
router.post("/store", authControllers.protect, postsControllers.createPost);

module.exports = router;
