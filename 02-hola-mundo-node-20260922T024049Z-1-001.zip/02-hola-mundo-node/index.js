// Importar paquete "http" de Node
const http = require("http");

const ipServidor = "127.0.0.1";
const puerto = 3000;

//Crear servidor web de Node
// req es el objeto de la petición ("request") con la infromación scolicitada
// res es el objeto con la respuesta del servidor
const servidor = http.createServer((req, res) => {
  // Regresar codigo de exito
  res.statusCode = 200;
  res.setHeader("Content-type", "text/plain");
  res.end("Holi mundo");
});

// Escuchar peticiones desde el servidor
servidor.listen(puerto, ipServidor, () => {
  console.log(`Servidor escuchando en http://` + `${ipServidor}:${puerto}`);
  console.log("Ctrl-C para terminar");
});
