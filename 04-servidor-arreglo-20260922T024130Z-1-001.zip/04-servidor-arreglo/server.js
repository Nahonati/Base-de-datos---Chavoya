const express = require("express");
const puerto = 3000;
const app = express();
let ultimoId = 3;

// Arreglo de objetos que simulen una tabla de posteos
const blogPosts = [
  {
    id: 1,
    title: "Wikipedia",
    content:
      "Wikipedia es una enciclopedia libre,[nota 2]​ políglota y editada de manera colaborativa. Es administrada por la Fundación Wikimedia, una organización sin ánimo de lucro cuya financiación está basada en donaciones. Sus más de 63 millones de artículos en 334 idiomas han sido redactados en conjunto por voluntarios de todo el mundo,[5]​ lo que suma más de 3500 millones de ediciones, y permite que cualquier persona pueda sumarse al proyecto[6]​ para editarlos, a menos que la página se encuentre protegida contra vandalismos para evitar problemas o disputas.",
    author: "Juan Perez",
    postDate: new Date(),
    views: 0,
  },
  {
    id: 2,
    title: "Node.js",
    content:
      "Node.js es un entorno en tiempo de ejecución multiplataforma, de código abierto, para la capa del servidor (pero no limitándose a ello) basado en el lenguaje de programación JavaScript, asíncrono, con E/S de datos en una arquitectura orientada a eventos y basado en el motor V8 de Google. Fue creado con el enfoque de ser útil en la creación de programas de red altamente escalables, como por ejemplo, servidores web.[4]​ Fue creado por Ryan Dahl en 2009 y su evolución está apadrinada por la empresa Joyent, que además tiene contratado a Dahl en plantilla.[5]​[6]",
    author: "María Islas",
    postDate: new Date(),
    views: 0,
  },
  {
    id: 3,
    title: "Express.js",
    content:
      "Express.js o simplemente Express es un entorno de trabajo para aplicaciones web en Node.js, de código abierto y con licencia MIT. Se utiliza para desarrollar aplicaciones web y APIs. El autor original es TJ Holowaychuk y la primera versión se lanzó el 2010. Express.js forma parte del programario MEAN, juntamente con MongoDB, Angular.js y Node.js.",
    author: "Christian Ruiz",
    postDate: new Date(),
    views: 0,
  },
];

// Indicar que en el cuerpo de la petición del cliente puede haber
// información en formato JSON o en formato x-www-form-urlencoded
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// GET de todos los posteos con la ruta /blogposts
app.get("/blogposts", (req, res) => {
  // Regresar el arreglo completo de posteos
  res.json(blogPosts);
});

// GET para un posteo particular ruta /blogposts/:id
app.get("/blogposts/:id", (req, res) => {
  // Obtener id de los parametros de la petición y convertir a enter
  // console.log(req.params.id);
  const idx = parseInt(req.params.id);

  // Obtener del arreglo de objetos aquel id buscado
  const blogPost = blogPosts.find((p) => p.id === idx);

  if (!blogPost) {
    return res.status(404).json({ message: "Recurso no encontrado" });
  }

  // Actualizar el número de views
  blogPost.views++;

  res.json(blogPost);
});

// Get de la ruta /
app.get("/", (req, res) => {
  res.json({ message: "La página principal" });
});

// POST de un posteo nuevo en la ruta /blogposts
app.post("/blogposts", (req, res) => {
  //console.log(req.body);
  // Obtener valor de las porpiedades del postero por "desestructuración"
  let { title, content, author } = req.body;

  // Eliminat posibles espacios en blanco antes y después del dato
  if (title) title = title.trim();
  if (content) content = content.trim();
  if (author) author = author.trim();

  // Verificar si no se tiene toda la información (title, content, author)
  if (!title || !content || !author) {
    return res.status(400).json({ message: "Datos incompletos" });
  }

  // Crear un objeto del posteo nuevo
  const newBlogPost = {
    id: ++ultimoId,
    title, // title: title
    content,
    author,
    postDate: new Date(),
    views: 0,
  };

  // Agregar objeto al final del arreglo
  blogPosts.push(newBlogPost);

  // Regresar el objeto recién agregado
  res.status(201).json(newBlogPost);
});

//PATCH para modificar un recurso dato en la ruta /blogpost/:id
app.patch("/blogposts/:id", (req, res) => {
  const idx = parseInt(req.params.id);

  const idxArr = blogPosts.findIndex((p) => p.id === idx);

  // Verificar si no existe el registro con el id dado
  if (idx === -1) {
    return res.status(404).json({ message: "Recurso no encontrado" });
  }

  // Verificar si no existe el objeto req.body
  if (!req.body) {
    return res.status(404).json({ message: "Datos incompletos" });
  }
  console.log(req.body);

  // Recuperar la información modificar del cuerpo de la petición
  let { title, content, author } = req.body;

  // Eliminar espacios en blanco antes y después del dato
  if (title) title = title.trim();
  if (content) content = content.trim();
  if (author) author = author.trim();

  //console.log({ title, content, author });

  // Verificar si no se envió por lo menos uno de los tres campos
  if (!(title || content || author)) {
    return res.status(404).json({ message: "Datos incompletos" });
  }

  // Actualizar el objeto en el arreglo con el o los campos enviados
  if (title) blogPosts[idxArr].title = title;
  if (content) blogPosts[idxArr].content = content;
  if (author) blogPosts[idxArr].author = author;

  // Regresar el objeto modificado
  res.json(blogPosts[idxArr]);
});

// Delete para eliminar el recurso específicado con ruta /blogpost/:id
app.delete("/blogposts/:id", (req, res) => {
  //Obtener id y convertir a entero
  const idx = parseInt(req.params.id);

  // Obtener indice del objeto en el arreglo con el id buscado
  const idxArr = blogPosts.findIndex((p) => p.id === idx);

  console.log(idx);
  console.log(idxArr);
  // Verificar si no se encontro el objeto en el arreglo
  if (idxArr === -1) {
    return res.status(404).json({ message: "Recurso no encontrado" });
  }

  // Eliminar objeto del arreglo
  const deletedPost = blogPosts.splice(idxArr, 1);

  // Reggresar elemento eliminado (Del arreglo regresado por splice)
  res.json(deletedPost[0]);
});

// Recursos no encontrados
app.use((req, res) => {
  res.status(404);
  res.json({ message: "Recurso no encontrado" });
});

// Error de servidor
app.use((err, req, res) => {
  res.status(500).json({ message: "Error del servidor" });
});

// Iniciar el servidor
app.listen(puerto, () => {
  console.log(`Servidor escuchando por el puerto ${puerto}...`);
});
